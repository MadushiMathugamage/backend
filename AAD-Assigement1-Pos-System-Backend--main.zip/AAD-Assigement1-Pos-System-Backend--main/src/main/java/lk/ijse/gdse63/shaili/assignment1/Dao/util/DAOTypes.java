package lk.ijse.gdse63.shaili.assignment1.Dao.util;

public enum DAOTypes {
    CUSTOMER_DAO, ITEM_DAO,ORDER_DAO
}
