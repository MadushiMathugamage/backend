package lk.ijse.gdse63.shaili.assignment1.service.Custom;

import lk.ijse.gdse63.shaili.assignment1.DTO.ItemDTO;
import lk.ijse.gdse63.shaili.assignment1.service.SuperService;

public interface ItemService extends SuperService<ItemDTO,String> {
}
