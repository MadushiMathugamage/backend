package lk.ijse.gdse63.shaili.assignment1.Entity;

public interface SuperEntity {
}
