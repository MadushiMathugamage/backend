package lk.ijse.gdse63.shaili.assignment1.DTO;

public interface SuperDTO {

}
