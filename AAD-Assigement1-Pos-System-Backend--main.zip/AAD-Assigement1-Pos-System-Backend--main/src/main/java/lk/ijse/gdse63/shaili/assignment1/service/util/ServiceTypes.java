package lk.ijse.gdse63.shaili.assignment1.service.util;

public enum ServiceTypes {
    CUSTOMER_SERVICE,ITEM_SERVICE,ORDER_SERVICE
}
