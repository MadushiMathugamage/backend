package lk.ijse.gdse63.shaili.assignment1.Dao.custom;

import lk.ijse.gdse63.shaili.assignment1.Dao.SuperDAO;
import lk.ijse.gdse63.shaili.assignment1.Entity.Item;

public interface ItemDAO extends SuperDAO<Item,String> {
}
